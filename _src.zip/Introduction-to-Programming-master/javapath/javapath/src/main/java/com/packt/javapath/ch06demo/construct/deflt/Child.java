package com.packt.javapath.ch06demo.construct.deflt;

public class Child extends Parent{
    public Child() {
        super(10);
    }
    public Child(int i) {
        super(i);
    }
}
