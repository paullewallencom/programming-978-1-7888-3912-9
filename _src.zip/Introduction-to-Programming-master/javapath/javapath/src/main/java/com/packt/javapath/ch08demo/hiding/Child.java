package com.packt.javapath.ch08demo.hiding;

public class Child extends Parent {
    public String name = "Child";
    public String getName() {
        return this.name;
    }
}
