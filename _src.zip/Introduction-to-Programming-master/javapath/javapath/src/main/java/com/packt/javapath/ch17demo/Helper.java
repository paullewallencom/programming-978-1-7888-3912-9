package com.packt.javapath.ch17demo;

public class Helper {
    public double calculateResult(int i){
        // Maybe many lines of code here
        return i* 5;
    }
    public static void printResult(double d){
        // Maybe many lines of code here
        System.out.println("Result=" + d + " Great!");
    }

}
