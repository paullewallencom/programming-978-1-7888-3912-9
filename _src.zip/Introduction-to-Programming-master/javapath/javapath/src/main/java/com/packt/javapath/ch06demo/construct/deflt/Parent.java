package com.packt.javapath.ch06demo.construct.deflt;

public class Parent {
    public Parent(){
    }
    public Parent(int i) {
    }
}
