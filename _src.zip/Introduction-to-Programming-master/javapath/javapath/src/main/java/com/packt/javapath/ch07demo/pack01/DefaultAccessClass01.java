package com.packt.javapath.ch07demo.pack01;

class DefaultAccessClass01 {
}
