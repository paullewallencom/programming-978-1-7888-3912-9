package com.packt.javapath.ch08demo.hiding;

public class Parent extends Grandad {
    public String name = "Parent";
    public String getName() {
        return this.name;
    }

}
