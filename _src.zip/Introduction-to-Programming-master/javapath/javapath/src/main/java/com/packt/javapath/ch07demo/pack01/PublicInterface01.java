package com.packt.javapath.ch07demo.pack01;

public interface PublicInterface01 {
    String name = "PublicInterface01";

    class DefaultAccessClass{

    }

    interface DefaultAccessInterface {

    }
}
