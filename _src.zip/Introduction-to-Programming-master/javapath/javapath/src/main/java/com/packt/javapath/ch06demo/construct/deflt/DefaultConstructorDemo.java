package com.packt.javapath.ch06demo.construct.deflt;

public class DefaultConstructorDemo {
    public static void main(String... args){
        new Child();
    }
}
