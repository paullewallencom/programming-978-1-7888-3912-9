package com.packt.javapath.ch07demo.pack01;

interface DefaultAccessInterface01 {
    String name = "DefaultAccessInterface01";
}
