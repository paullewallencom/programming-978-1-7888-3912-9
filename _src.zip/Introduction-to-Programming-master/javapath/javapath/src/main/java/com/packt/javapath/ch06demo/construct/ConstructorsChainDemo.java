package com.packt.javapath.ch06demo.construct;

public class ConstructorsChainDemo {
    public static void main(String... args){
        new Child();
        new Child("The Blows");

    }

}
