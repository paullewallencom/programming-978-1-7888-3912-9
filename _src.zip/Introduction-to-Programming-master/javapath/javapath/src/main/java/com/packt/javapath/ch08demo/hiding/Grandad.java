package com.packt.javapath.ch08demo.hiding;

public class Grandad {
    public String name = "Grandad";

    public String getName() {
        return this.name;
    }
}
