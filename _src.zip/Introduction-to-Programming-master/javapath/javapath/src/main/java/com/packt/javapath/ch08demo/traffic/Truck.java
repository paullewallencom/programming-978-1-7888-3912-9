package com.packt.javapath.ch08demo.traffic;


public interface Truck extends Vehicle {
    void setPayloadPounds(int payloadPounds);
}
