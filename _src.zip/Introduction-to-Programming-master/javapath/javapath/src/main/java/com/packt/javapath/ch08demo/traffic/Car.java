package com.packt.javapath.ch08demo.traffic;

public interface Car extends Vehicle {
    void setPassengersCount(int passengersCount);

}
