package com.packt.javapath.ch12demo;

import org.apache.commons.lang3.StringUtils;


public class Exercise {

    public static void main(String... args){
        String s = null;

        int i = StringUtils.indexOf(s, "abc");

        s.indexOf("abc");

    }
}
