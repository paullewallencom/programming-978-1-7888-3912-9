package com.packt.javapath.ch06demo.transport;

public class KeywordThisDemo {
    public static void main(String... args){
        Truck truck = new Truck(500,2000,300);
        System.out.println(truck.getSpeedMph(10));

    }
}
