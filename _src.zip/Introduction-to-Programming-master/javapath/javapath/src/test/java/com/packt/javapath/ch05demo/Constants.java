package com.packt.javapath.ch05demo;

public interface Constants {
    String NAME = "name";
}
